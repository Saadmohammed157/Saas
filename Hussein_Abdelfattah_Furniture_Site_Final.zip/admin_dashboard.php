
<?php
// التحقق من كلمة المرور
$correct_password = "Saad.moh@1";  
if ($_POST['password'] !== $correct_password) {
    echo "Invalid Password!";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Admin Dashboard</h1>
    </header>
    <section class="admin-dashboard">
        <h2>Manage Products</h2>
        <form action="add_product.php" method="POST">
            <label for="product_name">Product Name:</label>
            <input type="text" id="product_name" name="product_name" required>
            <label for="product_image">Product Image URL:</label>
            <input type="text" id="product_image" name="product_image" required>
            <label for="product_price">Product Price:</label>
            <input type="text" id="product_price" name="product_price" required>
            <button type="submit" class="button">Add Product</button>
        </form>
    </section>
</body>
</html>
    