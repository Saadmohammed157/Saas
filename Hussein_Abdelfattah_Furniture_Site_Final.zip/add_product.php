
<?php
// التحقق من كلمة السر مرة أخرى
$correct_password = "Saad.moh@1";  
if ($_POST['password'] !== $correct_password) {
    echo "Invalid Password!";
    exit();
}

// التحقق من البيانات المدخلة
if (isset($_POST['product_name']) && isset($_POST['product_image']) && isset($_POST['product_price'])) {
    $product_name = $_POST['product_name'];
    $product_image = $_POST['product_image'];
    $product_price = $_POST['product_price'];

    // حفظ المنتج (يمكنك هنا إضافة الكود لتخزين المنتج في قاعدة بيانات أو ملف JSON)
    echo "Product added successfully!";
} else {
    echo "Please fill all fields!";
}
?>
    