
document.addEventListener('DOMContentLoaded', function() {
    const adminPassword = "Saad.moh@1"; 

    const form = document.querySelector('.admin-login form');
    form.addEventListener('submit', function(event) {
        event.preventDefault(); 

        const passwordInput = document.querySelector('#password');
        const enteredPassword = passwordInput.value;

        if (enteredPassword === adminPassword) {
            window.location.href = "admin_dashboard.php";  // تحويل المستخدم إلى لوحة التحكم
        } else {
            alert("Invalid Password!");
        }
    });
});
    